#!/bin/bash

# Create the project directory structure
mkdir -p netflix-analysis/{data,analysis,templates,static}

# Create data files
cat > netflix-analysis/data/netflix_titles.csv << 'EOF'
show_id,type,title,director,cast,country,release_year,rating,duration,listed_in
s1,Movie,The Dark Knight,Christopher Nolan,"Christian Bale, Heath Ledger",USA,2008,PG-13,152 minutes,Action
s2,TV Show,Stranger Things,"The Duffer Brothers","Millie Bobby Brown, Finn Wolfhard",USA,2016,TV-14,3 Seasons,Sci-Fi
s3,Movie,Extraction,Sam Hargrave,"Chris Hemsworth, Rudhraksh Jaiswal",USA,2020,R,116 minutes,Action
s4,TV Show,The Witcher,Lauren Schmidt,"Henry Cavill, Freya Allan",USA,2019,TV-MA,2 Seasons,Fantasy
s5,Movie,Bird Box,Susanne Bier,"Sandra Bullock, Trevante Rhodes",USA,2018,R,124 minutes,Thriller
EOF

cat > netflix-analysis/data/user_viewing_history.csv << 'EOF'
user_id,show_id,watch_date,watch_duration_min,rating
1,s1,2023-01-10,152,5
1,s2,2023-01-15,180,4
2,s3,2023-02-05,116,3
2,s4,2023-02-10,120,5
3,s5,2023-03-01,124,4
EOF

# Create analysis files
cat > netflix-analysis/analysis/data_cleaning.py << 'EOF'
import pandas as pd

def load_and_clean_data():
    # Load datasets
    netflix_titles = pd.read_csv('data/netflix_titles.csv')
    user_history = pd.read_csv('data/user_viewing_history.csv')

    # Clean data
    netflix_titles['duration'] = netflix_titles['duration'].str.replace(' minutes', '').str.replace(' Seasons', '')
    netflix_titles['duration'] = pd.to_numeric(netflix_titles['duration'], errors='coerce')

    # Merge data
    merged_data = user_history.merge(netflix_titles, on='show_id')

    return {
        'netflix_titles': netflix_titles,
        'user_history': user_history,
        'merged_data': merged_data
    }
EOF

cat > netflix-analysis/analysis/analysis.py << 'EOF'
import pandas as pd

def analyze_data(data):
    # Top genres by watch time
    top_genres = data['merged_data'].groupby('listed_in')['watch_duration_min'].sum().sort_values(ascending=False)

    # Average watch time per user
    avg_watch_time = data['merged_data'].groupby('user_id')['watch_duration_min'].sum().mean()

    # Binge behavior (users watching multiple episodes/movies in a day)
    binge_users = data['merged_data'].groupby(['user_id', 'watch_date']).size().reset_index(name='count')
    binge_users = binge_users[binge_users['count'] > 1]

    # Ratings vs genres
    ratings_by_genre = data['merged_data'].groupby('listed_in')['rating'].mean().sort_values(ascending=False)

    return {
        'top_genres': top_genres,
        'avg_watch_time': avg_watch_time,
        'binge_users': binge_users,
        'ratings_by_genre': ratings_by_genre
    }
EOF

cat > netflix-analysis/analysis/visualizations.py << 'EOF'
import matplotlib.pyplot as plt
import seaborn as sns

def create_visualizations(analysis_results):
    plt.figure(figsize=(15, 10))

    # 1. Top Genres by Watch Time
    plt.subplot(2, 2, 1)
    analysis_results['top_genres'].head(5).plot(kind='bar', color='red')
    plt.title('Top 5 Genres by Watch Time')
    plt.ylabel('Total Watch Time (min)')

    # 2. Average Watch Time per User
    plt.subplot(2, 2, 2)
    plt.bar(['Avg Watch Time'], [analysis_results['avg_watch_time']], color='orange')
    plt.title('Average Watch Time per User (min)')

    # 3. Binge Watching Behavior
    plt.subplot(2, 2, 3)
    analysis_results['binge_users']['user_id'].value_counts().head(5).plot(kind='bar', color='purple')
    plt.title('Top 5 Binge Watchers')
    plt.xlabel('User ID')

    # 4. Ratings by Genre
    plt.subplot(2, 2, 4)
    analysis_results['ratings_by_genre'].head(5).plot(kind='barh', color='green')
    plt.title('Top 5 Highest-Rated Genres')

    plt.tight_layout()
    plt.savefig('static/insights.png')
    plt.close()
EOF

# Create app file
cat > netflix-analysis/app.py << 'EOF'
from flask import Flask, render_template
from analysis.data_cleaning import load_and_clean_data
from analysis.analysis import analyze_data
from analysis.visualizations import create_visualizations
import os

app = Flask(__name__)

@app.route('/')
def dashboard():
    data = load_and_clean_data()
    analysis_results = analyze_data(data)
    create_visualizations(analysis_results)

    return render_template('dashboard.html',
                         top_genres=analysis_results['top_genres'].head(5),
                         avg_watch_time=analysis_results['avg_watch_time'],
                         binge_users=analysis_results['binge_users'],
                         ratings_by_genre=analysis_results['ratings_by_genre'].head(5))

if __name__ == '__main__':
    if not os.path.exists('static'):
        os.makedirs('static')
    app.run(debug=True)
EOF

# Create template file
cat > netflix-analysis/templates/dashboard.html << 'EOF'
<!DOCTYPE html>
<html>
<head>
    <title>Netflix User Behavior Analysis</title>
    <style>
        body { font-family: Arial; margin: 20px; }
        .dashboard { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; }
        .card { background: #f5f5f5; padding: 15px; border-radius: 8px; }
        img { max-width: 100%; }
    </style>
</head>
<body>
    <h1>Netflix User Behavior Insights</h1>
    <div class="dashboard">
        <div class="card">
            <h2>Top Genres by Watch Time</h2>
            <img src="{{ url_for('static', filename='insights.png') }}" alt="Visualizations">
        </div>
        <div class="card">
            <h2>Average Watch Time: {{ avg_watch_time|round(1) }} min</h2>
        </div>
        <div class="card">
            <h2>Top Binge Watchers</h2>
            <ul>
                {% for user in binge_users['user_id'].unique()[:5] %}
                <li>User {{ user }}</li>
                {% endfor %}
            </ul>
        </div>
        <div class="card">
            <h2>Highest-Rated Genres</h2>
            <ol>
                {% for genre, rating in ratings_by_genre.items() %}
                <li>{{ genre }} ({{ rating|round(1) }}/5)</li>
                {% endfor %}
            </ol>
        </div>
    </div>
</body>
</html>
EOF

# Create README
cat > netflix-analysis/README.md << 'EOF'
# Netflix User Behavior Analysis

## Setup Instructions

1. Install required packages:
```bash
pip install pandas matplotlib seaborn flask