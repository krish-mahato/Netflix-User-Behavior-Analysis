import matplotlib
matplotlib.use('Agg')  # Must be before other imports
from flask import Flask, render_template
from flask import Flask, render_template
from analysis.data_cleaning import load_and_clean_data
from analysis.analysis import analyze_data
from analysis.visualizations import create_visualizations
import os

app = Flask(__name__)

@app.route('/.well-known/appspecific/com.chrome.devtools.json')
def chrome_devtools_config():
    return "{}", 200, {'Content-Type': 'application/json'}


@app.route('/')
def dashboard():
    data = load_and_clean_data()
    print("\nAvailable columns in merged data:", data['merged_data'].columns.tolist())  # Debug line
    analysis_results = analyze_data(data)
    create_visualizations(analysis_results)

    return render_template('dashboard.html',
                         top_genres=analysis_results['top_genres'].head(5),
                         avg_watch_time=analysis_results['avg_watch_time'],
                         binge_users=analysis_results['binge_users'],
                         ratings_by_genre=analysis_results['ratings_by_genre'].head(5))

if __name__ == '__main__':
    if not os.path.exists('static'):
        os.makedirs('static')
    app.run(debug=True)