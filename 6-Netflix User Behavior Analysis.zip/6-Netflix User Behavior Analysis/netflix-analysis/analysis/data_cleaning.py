import pandas as pd

def load_and_clean_data():
    # Load datasets
    netflix_titles = pd.read_csv('data/netflix_titles.csv')
    user_history = pd.read_csv('data/user_viewing_history.csv')

    # Clean data
    netflix_titles['duration'] = netflix_titles['duration'].str.replace(' minutes', '').str.replace(' Seasons', '')
    netflix_titles['duration'] = pd.to_numeric(netflix_titles['duration'], errors='coerce')

    # Merge data and rename rating columns
    merged_data = user_history.merge(netflix_titles, on='show_id', suffixes=('_user', '_netflix'))
    
    return {
        'netflix_titles': netflix_titles,
        'user_history': user_history,
        'merged_data': merged_data
    }