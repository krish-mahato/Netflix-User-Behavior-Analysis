import matplotlib
matplotlib.use('Agg')  # Must be before pyplot import
import matplotlib.pyplot as plt
import seaborn as sns

def create_visualizations(analysis_results):
    try:
        plt.figure(figsize=(15, 10))
        
        # 1. Top Genres by Watch Time
        plt.subplot(2, 2, 1)
        analysis_results['top_genres'].head(5).plot(kind='bar', color='red')
        plt.title('Top 5 Genres by Watch Time')
        plt.ylabel('Total Watch Time (min)')

        # 2. Average Watch Time per User
        plt.subplot(2, 2, 2)
        plt.bar(['Avg Watch Time'], [analysis_results['avg_watch_time']], color='orange')
        plt.title('Average Watch Time per User (min)')

        # 3. Binge Watching Behavior
        plt.subplot(2, 2, 3)
        analysis_results['binge_users']['user_id'].value_counts().head(5).plot(kind='bar', color='purple')
        plt.title('Top 5 Binge Watchers')
        plt.xlabel('User ID')

        # 4. Ratings by Genre
        plt.subplot(2, 2, 4)
        analysis_results['ratings_by_genre'].head(5).plot(kind='barh', color='green')
        plt.title('Top 5 Highest-Rated Genres')

        plt.tight_layout()
        plt.savefig('static/insights.png')
        plt.close()
    except Exception as e:
        print(f"Error creating visualizations: {e}")