# Netflix User Behavior Analysis

## Setup Instructions

1. Install required packages:
```bash
pip install pandas matplotlib seaborn flask
